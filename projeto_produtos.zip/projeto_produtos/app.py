from flask import Flask, request, jsonify, send_from_directory
import sqlite3
import os
from flask_cors import CORS

app = Flask(__name__)
CORS(app)  # Permite requisições do frontend

# Configuração do banco de dados
DATABASE = 'database.db'

def init_db():
    """Inicializa o banco de dados com a tabela de produtos"""
    conn = sqlite3.connect(DATABASE)
    cursor = conn.cursor()
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS produtos (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nome TEXT NOT NULL,
            preco REAL NOT NULL,
            descricao TEXT,
            imagem TEXT
        )
    ''')
    conn.commit()
    conn.close()

@app.route('/')
def serve_frontend():
    """Serve o arquivo HTML principal"""
    return send_from_directory('static', 'index.html')

@app.route('/static/<path:path>')
def serve_static(path):
    """Serve arquivos estáticos (CSS, JS)"""
    return send_from_directory('static', path)

# 🔄 CRUD de Produtos

@app.route('/produtos', methods=['POST'])
def criar_produto():
    """Cria um novo produto"""
    try:
        data = request.get_json()
        
        if not data or not data.get('nome') or not data.get('preco'):
            return jsonify({'error': 'Nome e preço são obrigatórios'}), 400
        
        conn = sqlite3.connect(DATABASE)
        cursor = conn.cursor()
        
        cursor.execute('''
            INSERT INTO produtos (nome, preco, descricao, imagem)
            VALUES (?, ?, ?, ?)
        ''', (data['nome'], data['preco'], data.get('descricao', ''), data.get('imagem', '')))
        
        conn.commit()
        produto_id = cursor.lastrowid
        conn.close()
        
        return jsonify({
            'id': produto_id,
            'nome': data['nome'],
            'preco': data['preco'],
            'descricao': data.get('descricao', ''),
            'imagem': data.get('imagem', '')
        }), 201
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/produtos', methods=['GET'])
def listar_produtos():
    """Lista todos os produtos"""
    try:
        conn = sqlite3.connect(DATABASE)
        cursor = conn.cursor()
        
        cursor.execute('SELECT * FROM produtos')
        produtos = cursor.fetchall()
        conn.close()
        
        # Converte para lista de dicionários
        produtos_list = []
        for produto in produtos:
            produtos_list.append({
                'id': produto[0],
                'nome': produto[1],
                'preco': produto[2],
                'descricao': produto[3],
                'imagem': produto[4]
            })
        
        return jsonify(produtos_list)
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/produtos/<int:produto_id>', methods=['PUT'])
def atualizar_produto(produto_id):
    """Atualiza um produto existente"""
    try:
        data = request.get_json()
        
        if not data:
            return jsonify({'error': 'Dados não fornecidos'}), 400
        
        conn = sqlite3.connect(DATABASE)
        cursor = conn.cursor()
        
        # Verifica se o produto existe
        cursor.execute('SELECT * FROM produtos WHERE id = ?', (produto_id,))
        if not cursor.fetchone():
            conn.close()
            return jsonify({'error': 'Produto não encontrado'}), 404
        
        # Atualiza o produto
        cursor.execute('''
            UPDATE produtos 
            SET nome = ?, preco = ?, descricao = ?, imagem = ?
            WHERE id = ?
        ''', (
            data.get('nome'), 
            data.get('preco'), 
            data.get('descricao', ''), 
            data.get('imagem', ''), 
            produto_id
        ))
        
        conn.commit()
        conn.close()
        
        return jsonify({'message': 'Produto atualizado com sucesso'})
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/produtos/<int:produto_id>', methods=['DELETE'])
def deletar_produto(produto_id):
    """Remove um produto"""
    try:
        conn = sqlite3.connect(DATABASE)
        cursor = conn.cursor()
        
        # Verifica se o produto existe
        cursor.execute('SELECT * FROM produtos WHERE id = ?', (produto_id,))
        if not cursor.fetchone():
            conn.close()
            return jsonify({'error': 'Produto não encontrado'}), 404
        
        cursor.execute('DELETE FROM produtos WHERE id = ?', (produto_id,))
        conn.commit()
        conn.close()
        
        return jsonify({'message': 'Produto deletado com sucesso'})
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

if __name__ == '__main__':
    init_db()  # Inicializa o banco na primeira execução
    app.run(debug=True, port=5000)
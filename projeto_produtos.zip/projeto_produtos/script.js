class ProductManager {
    constructor() {
        this.baseUrl = 'http://localhost:5000';
        this.products = [];
        this.editingProductId = null;
        
        this.initializeElements();
        this.bindEvents();
        this.loadProducts();
    }
    
    initializeElements() {
        this.productForm = document.getElementById('productForm');
        this.productsGrid = document.getElementById('productsGrid');
        this.emptyState = document.getElementById('emptyState');
        this.submitButton = document.getElementById('submitButton');
        this.cancelEditButton = document.getElementById('cancelEdit');
        this.formTitle = document.getElementById('formTitle');
    }
    
    bindEvents() {
        this.productForm.addEventListener('submit', (e) => this.handleSubmit(e));
        this.cancelEditButton.addEventListener('click', () => this.cancelEdit());
    }
    
    async loadProducts() {
        try {
            this.showLoading();
            const response = await fetch(`${this.baseUrl}/produtos`);
            
            if (!response.ok) {
                throw new Error('Erro ao carregar produtos');
            }
            
            this.products = await response.json();
            this.renderProducts();
            
        } catch (error) {
            console.error('Erro:', error);
            this.showError('Erro ao carregar produtos');
        }
    }
    
    async handleSubmit(e) {
        e.preventDefault();
        
        const formData = new FormData(this.productForm);
        const productData = {
            nome: formData.get('nome'),
            preco: parseFloat(formData.get('preco')),
            descricao: formData.get('descricao'),
            imagem: formData.get('imagem')
        };
        
        try {
            if (this.editingProductId) {
                await this.updateProduct(this.editingProductId, productData);
            } else {
                await this.createProduct(productData);
            }
            
            this.resetForm();
            await this.loadProducts();
            
        } catch (error) {
            console.error('Erro:', error);
            this.showError('Erro ao salvar produto');
        }
    }
    
    async createProduct(productData) {
        const response = await fetch(`${this.baseUrl}/produtos`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(productData)
        });
        
        if (!response.ok) {
            throw new Error('Erro ao criar produto');
        }
        
        this.showSuccess('Produto criado com sucesso!');
    }
    
    async updateProduct(productId, productData) {
        const response = await fetch(`${this.baseUrl}/produtos/${productId}`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(productData)
        });
        
        if (!response.ok) {
            throw new Error('Erro ao atualizar produto');
        }
        
        this.showSuccess('Produto atualizado com sucesso!');
    }
    
    async deleteProduct(productId) {
        if (!confirm('Tem certeza que deseja excluir este produto?')) {
            return;
        }
        
        try {
            const response = await fetch(`${this.baseUrl}/produtos/${productId}`, {
                method: 'DELETE'
            });
            
            if (!response.ok) {
                throw new Error('Erro ao deletar produto');
            }
            
            this.showSuccess('Produto excluído com sucesso!');
            await this.loadProducts();
            
        } catch (error) {
            console.error('Erro:', error);
            this.showError('Erro ao excluir produto');
        }
    }
    
    editProduct(product) {
        this.editingProductId = product.id;
        
        // Preenche o formulário com os dados do produto
        document.getElementById('nome').value = product.nome;
        document.getElementById('preco').value = product.preco;
        document.getElementById('descricao').value = product.descricao || '';
        document.getElementById('imagem').value = product.imagem || '';
        
        // Altera o formulário para modo edição
        this.submitButton.textContent = 'Atualizar Produto';
        this.submitButton.className = 'btn btn-success';
        this.cancelEditButton.classList.remove('hidden');
        this.formTitle.textContent = 'Editar Produto';
        
        // Rola até o formulário
        this.productForm.scrollIntoView({ behavior: 'smooth' });
    }
    
    cancelEdit() {
        this.resetForm();
    }
    
    resetForm() {
        this.productForm.reset();
        this.editingProductId = null;
        this.submitButton.textContent = 'Cadastrar Produto';
        this.submitButton.className = 'btn btn-primary';
        this.cancelEditButton.classList.add('hidden');
        this.formTitle.textContent = 'Cadastrar Novo Produto';
    }
    
    renderProducts() {
        if (this.products.length === 0) {
            this.emptyState.classList.remove('hidden');
            this.productsGrid.innerHTML = '';
            return;
        }
        
        this.emptyState.classList.add('hidden');
        
        this.productsGrid.innerHTML = this.products.map(product => `
            <div class="product-card">
                <img src="${product.imagem || 'https://picsum.photos/300/200'}" 
                     alt="${product.nome}" 
                     class="product-image"
                     onerror="this.src='https://picsum.photos/300/200'">
                <div class="product-info">
                    <h3 class="product-name">${this.escapeHtml(product.nome)}</h3>
                    <div class="product-price">R$ ${product.preco.toFixed(2)}</div>
                    <p class="product-description">${this.escapeHtml(product.descricao) || 'Sem descrição'}</p>
                    <div class="product-actions">
                        <button class="btn btn-secondary" onclick="productManager.editProduct(${this.escapeHtml(JSON.stringify(product))})">
                            Editar
                        </button>
                        <button class="btn btn-danger" onclick="productManager.deleteProduct(${product.id})">
                            Excluir
                        </button>
                    </div>
                </div>
            </div>
        `).join('');
    }
    
    showLoading() {
        this.productsGrid.innerHTML = `
            <div class="loading">
                <p>Carregando produtos...</p>
            </div>
        `;
    }
    
    showSuccess(message) {
        alert(message); // Em uma aplicação real, use um sistema de notificação mais sofisticado
    }
    
    showError(message) {
        alert(`Erro: ${message}`); // Em uma aplicação real, use um sistema de notificação mais sofisticado
    }
    
    escapeHtml(unsafe) {
        if (typeof unsafe !== 'string') return unsafe;
        return unsafe
            .replace(/&/g, "&amp;")
            .replace(/</g, "&lt;")
            .replace(/>/g, "&gt;")
            .replace(/"/g, "&quot;")
            .replace(/'/g, "&#039;");
    }
}

// Inicializa o gerenciador de produtos quando a página carregar
let productManager;

document.addEventListener('DOMContentLoaded', () => {
    productManager = new ProductManager();
});